<?php
 return array (
  'app_version' => '1.7',
  'update_url' => 'https://marketplace.gainhq.com',
  'app_id' => 'gain-pos',
  'installed' => true,
) ;