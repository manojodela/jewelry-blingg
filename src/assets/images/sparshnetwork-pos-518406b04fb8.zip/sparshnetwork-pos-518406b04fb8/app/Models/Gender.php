<?php

namespace App\Models;

class Gender extends BaseModel
{
    protected $table = 'genders';
    protected $fillable = ['name', 'short_name']; 

}
