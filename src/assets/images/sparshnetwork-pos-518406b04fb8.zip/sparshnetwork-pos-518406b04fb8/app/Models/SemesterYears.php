<?php

namespace App\Models;

class SemesterYears extends BaseModel
{
    protected $table = 'semester_years';
    protected $fillable = ['title']; 

}
