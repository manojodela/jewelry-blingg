<?php

namespace App\Models;


class Profile extends BaseModel
{

}
