<?php


namespace App\Http\Controllers\API\Export;


use App\Exports\CustomersExport;
use App\Http\Controllers\Controller;

class CustomersExportController extends Controller
{

    public function exportAllCustomers()
    {
        return (new CustomersExport)->download('customers.xlsx');
    }
}